#include<iostream>
#include<fstream>
#include "../header/input.h"

int main(){
  input tes;
  tes.cetak();
  tes.senddata();
}
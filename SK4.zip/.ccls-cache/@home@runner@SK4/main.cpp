#include"header/proses.h"
#include"header/input.h"
#include"header/output.h"

int main() {
  input input;
  proses proses;
  Output output;
  
  input.cetak();
  input.senddata();
  cout<<endl;
  proses.getdata();
  proses.hitung();
  proses.senddata();
  cout<<endl;
  output.getData();
  output.cetak();
  
}
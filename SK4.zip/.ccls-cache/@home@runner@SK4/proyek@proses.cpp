#include"../header/proses.h"

int main(){
  proses proses;
  proses.getdata();
  proses.hitung();
  proses.senddata();
  return 0;
}
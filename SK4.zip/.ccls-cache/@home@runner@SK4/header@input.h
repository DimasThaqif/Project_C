using namespace std;
class input{
  public:
    void senddata(){
      kirimdata.open("fix.txt");
      kirimdata<<jajan;
      kirimdata.close();
    }
    void cetak(){
      cout<<"masukkan uang jajan perbulan : ";
      cin>>jajan;
    }
  private : 
    ofstream kirimdata;
    int jajan;
};
using namespace std;

class Output{
  public:
      void cetak(){
        cout<<"Tabungan & Pengeluaran Andi"<<endl;
        cout<<"Total duit : "<<data_file[3]<<endl;
        cout<<"Pengeluaran Tiap Bulan : "<<data_file[1]<<endl;
        cout<<"Total Pengeluaran      : "<<data_file[2]<<endl;
        cout<<"Uang Tabungan Saat ini : "<<data_file[0]<<endl;
        
      }
      void getData(){
        ambil_data.open("fix.txt");
        while(!ambil_data.eof()){
          ambil_data>>data_file[index];
    index++;  
          }
        ambil_data.close();
        
      }
    private:
    ifstream ambil_data;
    string data_file[100];
    int index = 0;

};
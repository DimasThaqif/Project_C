#include<iostream>
#include<fstream>
using namespace std;

class proses{
  public:
    void getdata(){
      ambildata.open("fix.txt");
      while(!ambildata.eof()){
        ambildata>>gaji;
      }
      ambildata.close();
    }

    void senddata(){
      kirimdata.open("fix.txt");
      kirimdata<<uangtabungan<<endl;
      kirimdata<<perbulan<<endl;
      kirimdata<<totalkeluar<<endl;
      kirimdata<<uangtabungan2;
      kirimdata.close();
    }

    void hitung(){
      cout<<"Ingin kalkulasi berapa bulan : ";
      cin>>bulan;
      cout<<"Berapa pengeluaranmu perbulan : ";
      cin>>perbulan;
      for(int a=1; a<=bulan; a++){
        uangtabungan+=gaji;
      }
      uangtabungan2=uangtabungan;
      totalkeluar=bulan*perbulan;
      uangtabungan-=totalkeluar;
    }
  private:
    ofstream kirimdata;
    ifstream ambildata;
    int gaji, perbulan, bulan, uangtabungan2;
    int uangtabungan=0, totalkeluar=0;
};
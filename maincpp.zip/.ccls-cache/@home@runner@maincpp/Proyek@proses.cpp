#include<iostream>
#include<fstream>
#include"../header/proses.h"

int main(){
  proses titit;
  titit.getdata();
  titit.senddata();
  return 0;
}